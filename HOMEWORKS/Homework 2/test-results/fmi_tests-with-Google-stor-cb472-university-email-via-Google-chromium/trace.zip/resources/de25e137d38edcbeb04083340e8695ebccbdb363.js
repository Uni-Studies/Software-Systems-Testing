(function ($) {
 "use strict";

	//$('.chosen-select').chosen({width: "100%"});

	$(".chosen-select").chosen({
        no_results_text: "Няма намерени резултати за: ",
        enable_split_word_search: false,
        width: "100%",
		display_disabled_options: false,
		allow_single_deselect: true
    });

})(jQuery); 